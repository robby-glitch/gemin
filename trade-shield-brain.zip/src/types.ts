/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type InstrumentName = 'NIFTY' | 'BANKNIFTY' | 'SENSEX' | 'HDFCBANK' | 'RELIANCE' | 'ICICIBANK' | 'BAJFINANCE' | 'SBIN' | 'AXISBANK';

export interface Bar {
  time: string; // ISO string or IST HH:MM:SS
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface OptionData {
  strike: number;
  type: 'CE' | 'PE';
  ltp: number;
  oi: number;
  iv: number;
  high: number;
}

export interface OptionChain {
  instrument: InstrumentName;
  expiryDate: string;
  timestamp: string;
  options: OptionData[];
}

export interface PivotPoints {
  P: number;
  R1: number;
  S1: number;
  R2: number;
  S2: number;
  fibUp: number[];
  fibDown: number[];
}

export interface PivotHighLow {
  index: number;
  isHigh: boolean;
  price: number;
  bar: Bar;
}

export interface OrderBlock {
  id: string;
  isDemand: boolean; // true = demand (OB created on bullish break), false = supply
  priceHigh: number;
  priceLow: number;
  mitigated: boolean;
  mitigatedBarIndex?: number;
  createdBarIndex: number;
  volume: number;
}

export interface EqualHighLow {
  price: number;
  isHigh: boolean;
  barIndices: number[];
}

export interface SMCState {
  trendBias: number; // +1 bullish, -1 bearish
  lastOpposingChochBar: number; // index of bar where last opposing CHoCH occurred
  orderBlocks: OrderBlock[];
  equalHighs: EqualHighLow[];
  equalLows: EqualHighLow[];
  strongHigh?: number;
  strongLow?: number;
  equilibriumZone: { mid: number; upper: number; lower: number };
  confirmedLagBars: number;
}

export type MachineState = 'IDLE' | 'ARMED' | 'STAND_DOWN' | 'TRIGGER' | 'EXPIRED' | 'DATA STALE';

export type VerdictType = 'FADE LONG' | 'FADE SHORT' | 'STAND DOWN' | 'NOTHING' | 'OBSERVE' | 'DATA STALE';

export type VetoType = 'V0' | 'V1' | 'V2' | 'V3' | 'V4' | 'V5' | 'V6' | 'V7';

export interface InstrumentState {
  instrument: InstrumentName;
  state: MachineState;
  verdict: VerdictType;
  direction: 'up' | 'down' | null;
  armBarIndex: number | null;
  zAtArm: number | null;
  zAtTrigger: number | null;
  activeVeto: VetoType | null;
  sizeNotch: number; // 1, 2, or 3
  anchorStrike: number | null;
  coiled: boolean;
  coilBps: number | null;
  mirrorState: 'NEUTRAL' | 'CONFIRMING' | 'AVALANCHE' | 'REJECTION';
  siblingsConfirmCount: number;
  lastUpdate: string;
  dte: number;
}

export interface VerdictLogEntry {
  id: string;
  ts_ist: string;
  instrument: InstrumentName;
  module: 'pocket' | 'scanner' | 'avalanche';
  state_from: MachineState;
  state_to: MachineState;
  verdict: VerdictType;
  veto: VetoType | null;
  z_arm: number | null;
  z_trigger: number | null;
  dte: number;
  coil_bps: number | null;
  mirror_state: string;
  siblings: number;
  choch_opposing: boolean;
  choch_age_bars: number;
  size_notch: number;
  leg: string; // e.g. "K CE" or "K PE"
  strike: number;
  ltp_at_flag: number;
  stop_band: number;
  stop_struct: number;
  target_pct: number;
  target_struct_level: number;
  outcome: 'WIN' | 'LOSS' | 'PENDING' | 'INVALIDATED' | null;
  outcome_ts: string | null;
  mfe: number; // Max Favorable Excursion %
  mae: number; // Max Adverse Excursion %
  premium_max_pct: number;
  stop_band_result: 'HIT' | 'MISSED' | null;
  stop_struct_result: 'HIT' | 'MISSED' | null;
  target_pct_result: 'HIT' | 'MISSED' | null;
  target_struct_result: 'HIT' | 'MISSED' | null;
  notes: string;
}

export interface SystemConfig {
  auth: {
    token_env: string;
    client_env: string;
  };
  clock: {
    tz: string;
    session: [string, string];
    anchor_time: string;
    entry_cutoff: string;
    min_bars_before_arm: number;
  };
  bands: {
    arm_z: number;
    disqualify_z: number;
    rearm_z: number;
    sigma_source: 'spot_twap';
  };
  mirror: {
    avalanche_confirm_bars: number;
    arm_window_bars: number;
    touch_lookback_bars: number;
  };
  oi: {
    both_legs_window_bars: number;
    drain_pct: number;
    drain_mode: 'log_only';
  };
  coil: {
    eval_time: string;
    coiled_max_bps: number;
  };
  pocket: {
    indices: InstrumentName[];
    min_dte: number;
    z_low: number;
    z_high: number;
    stop_premium_pct: number;
    scale_half_pct: number;
    magnet_min_pct: number;
    time_stop_bars: number;
    stop_spot_sigma: number;
  };
  scanner: {
    max_flags: number;
    index_calm_z: number;
    level_prox_sigma: number;
    stop_sigma: number;
    target_sigma: number;
    whitelist: InstrumentName[];
    probation: InstrumentName[];
    excluded: InstrumentName[];
  };
  avalanche: {
    mode: 'paper' | 'live';
    min_siblings: number;
    sibling_z: number;
    stop_pct: number;
    scale_half_pct: number;
    promote_min_signals: number;
    promote_min_winrate: number;
  };
  smc: {
    enabled: boolean;
    size: number;
    eq_len: number;
    eq_thresh: number;
    atr_len: number;
    mitigation: 'CLOSE' | 'TOUCH';
    ob_stop_pad_sigma: number;
    choch_demotion_lookback_bars: number;
    choch_mode: 'sizing_demotion';
  };
  expiry_weekday: { [key in InstrumentName]?: string };
  cadence_s: {
    index_bars: number;
    stock_bars: number;
    index_chain: number;
    stock_chain: number;
    ui_poll: number;
    chain_min_gap: number;
  };
  alerts: {
    telegram_token_env: string;
    chat_id_env: string;
  };
  audit: {
    label_time: string;
    requalify_day: string;
    benchmark_day: number;
    requalify_whitelist_min: number;
    requalify_exclude_below: number;
    kill_pocket_rolling_n: number;
    choch_review_n: number;
  };
}
