/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { InstrumentState, VerdictLogEntry, InstrumentName } from './types';
import { Dashboard } from './components/Dashboard';
import { Journal } from './components/Journal';
import { Settings } from './components/Settings';
import { ShieldAlert, Calendar, Sliders, Clock, Radio, Activity } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'journal' | 'settings'>('dashboard');
  const [instruments, setInstruments] = useState<(InstrumentState & { spotPrice: number; smc: any })[]>([]);
  const [verdicts, setVerdicts] = useState<VerdictLogEntry[]>([]);
  const [tiers, setTiers] = useState<{ [key in InstrumentName]?: any }>({});
  const [settings, setSettings] = useState<any>({
    alertsEnabled: true,
    simulationMode: true,
    telegramToken: '',
    telegramChatId: '',
    dhanToken: '',
    dhanClientId: '',
  });

  const [istTime, setIstTime] = useState('');
  const [lastPollTime, setLastPollTime] = useState<Date>(new Date());
  const [isOffline, setIsOffline] = useState(false);

  // 1. Fetch State & Journal data
  const fetchData = async () => {
    try {
      const stateRes = await fetch('/api/state');
      const stateData = await stateRes.json();
      setInstruments(stateData.instruments || []);
      setSettings(stateData.settings || {});

      const journalRes = await fetch('/api/journal');
      const journalData = await journalRes.json();
      setVerdicts(journalData.verdicts || []);
      setTiers(journalData.tiers || {});

      setLastPollTime(new Date());
      setIsOffline(false);
    } catch (e) {
      console.error('[Client] Failed to pull API data', e);
      setIsOffline(true);
    }
  };

  useEffect(() => {
    fetchData();
    const poll = setInterval(fetchData, 5000); // 5s Poller as per specification

    // IST Clock ticker (Section 7.2)
    const tickClock = () => {
      const now = new Date();
      const formatted = now.toLocaleTimeString('en-US', {
        timeZone: 'Asia/Kolkata',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setIstTime(formatted + ' IST');
    };
    tickClock();
    const clockInterval = setInterval(tickClock, 1000);

    return () => {
      clearInterval(poll);
      clearInterval(clockInterval);
    };
  }, []);

  // Actions
  const handleSaveSettings = async (updates: any) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      setSettings(data.settings);
      fetchData();
    } catch (e) {
      console.error('[Client] Failed to update settings', e);
    }
  };

  const handleTriggerScenario = async (instrument: InstrumentName, scenario: string) => {
    try {
      await fetch('/api/simulate-scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instrument, scenario }),
      });
      fetchData();
    } catch (e) {
      console.error('[Client] Scenario trigger failed', e);
    }
  };

  const handleTriggerAuditor = async (job: string) => {
    try {
      await fetch('/api/trigger-auditor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ job }),
      });
      fetchData();
    } catch (e) {
      console.error('[Client] Failed to trigger auditor', e);
    }
  };

  const handleSaveStrikeOverride = async (instrument: InstrumentName, strike: number | undefined) => {
    try {
      await fetch('/api/manual-strike', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instrument, strike }),
      });
      fetchData();
    } catch (e) {
      console.error('[Client] Override failed', e);
    }
  };

  // Freshness calculation (Section 7.2)
  const freshnessSec = Math.floor((Date.now() - lastPollTime.getTime()) / 1000);
  const freshnessDot = freshnessSec <= 10 ? 'bg-emerald-500' : freshnessSec <= 360 ? 'bg-amber-500' : 'bg-red-500';

  return (
    <div className="min-h-screen bg-[#101214] text-[#E8E6E1] flex flex-col font-sans">
      {/* Top Status Bar (Section 7.2) */}
      <header className="border-b border-[#2A2E33] bg-[#1A1D21] sticky top-0 z-30 px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          {/* Brand & Ticker Freshness */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-emerald-950/40 text-emerald-400 border border-emerald-900 rounded-full px-2.5 py-1 text-xs font-mono font-bold">
              <Activity className="w-3.5 h-3.5 animate-pulse" />
              Trade Shield Brain
            </div>
            <div className="flex items-center gap-1.5 text-xs text-gray-500 font-mono">
              <span className={`h-2 w-2 rounded-full ${freshnessDot} animate-pulse`} />
              <span>Feed Freshness: {isOffline ? 'OFFLINE' : `${freshnessSec}s`}</span>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="flex items-center gap-1 bg-[#101214] border border-[#2A2E33] p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-1.5 text-xs font-mono rounded-md flex items-center gap-1.5 transition ${
                activeTab === 'dashboard' ? 'bg-[#1A1D21] text-[#E8E6E1] font-semibold border border-[#2A2E33]' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" /> Dashboard
            </button>
            <button
              onClick={() => setActiveTab('journal')}
              className={`px-3 py-1.5 text-xs font-mono rounded-md flex items-center gap-1.5 transition ${
                activeTab === 'journal' ? 'bg-[#1A1D21] text-[#E8E6E1] font-semibold border border-[#2A2E33]' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" /> Journal
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1.5 text-xs font-mono rounded-md flex items-center gap-1.5 transition ${
                activeTab === 'settings' ? 'bg-[#1A1D21] text-[#E8E6E1] font-semibold border border-[#2A2E33]' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" /> Settings
            </button>
          </nav>

          {/* Clock Info & Status Chips */}
          <div className="flex items-center gap-4 text-xs font-mono">
            {settings.simulationMode && (
              <span className="px-2 py-0.5 rounded text-[10px] font-bold border border-amber-800 bg-amber-950/40 text-amber-300">
                SIMULATION LIVE
              </span>
            )}
            <div className="flex items-center gap-1.5 text-gray-400 font-semibold bg-gray-900 border border-gray-800 px-2.5 py-1 rounded">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              {istTime || 'Loading Clock...'}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Pane */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
        {activeTab === 'dashboard' && (
          <Dashboard instruments={instruments} onTriggerScenario={handleTriggerScenario} />
        )}
        {activeTab === 'journal' && <Journal verdicts={verdicts} />}
        {activeTab === 'settings' && (
          <Settings
            settings={settings}
            tiers={tiers}
            onSaveSettings={handleSaveSettings}
            onTriggerAuditor={handleTriggerAuditor}
            onSaveStrikeOverride={handleSaveStrikeOverride}
          />
        )}
      </main>

      {/* Footer copyright */}
      <footer className="border-t border-[#2A2E33] bg-[#1A1D21] py-4 text-center text-xs text-gray-600 font-mono">
        &copy; 2026 Mary Intraday F&amp;O • Trade Shield Brain v1.1. Built for Refusal Discipline.
      </footer>
    </div>
  );
}
