/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { InstrumentState, InstrumentName } from '../types';
import { ShieldAlert, TrendingUp, TrendingDown, Eye, AlertCircle, Info, Zap, Layers, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DashboardProps {
  instruments: (InstrumentState & { spotPrice: number; smc: any })[];
  onTriggerScenario: (instrument: InstrumentName, scenario: string) => void;
}

// Highly precise SMC Strength/Alignment calculator
const getSMCStrength = (smc: any, spotPrice: number) => {
  if (!smc) return 0;
  let score = 20; // Base score for established trend bias

  // 1. Change of Character (CHoCH) stability (no recent opposing break)
  if (smc.lastOpposingChochBar === -1) {
    score += 20;
  } else {
    score += 10;
  }

  // 2. Order Block support
  const unmitigated = smc.orderBlocks?.filter((ob: any) => !ob.mitigated) || [];
  const alignedOBs = unmitigated.filter((ob: any) => ob.isDemand === (smc.trendBias === 1));
  if (alignedOBs.length > 0) {
    score += 30;
  } else if (unmitigated.length > 0) {
    score += 15;
  }

  // 3. Equilibrium Premium/Discount alignment
  if (smc.equilibriumZone) {
    const refPrice = spotPrice || smc.equilibriumZone.mid;
    const isBullish = smc.trendBias === 1;
    const isDiscount = refPrice <= smc.equilibriumZone.mid;
    // In SMC, buy in discount (for bullish) or sell in premium (for bearish)
    if ((isBullish && isDiscount) || (!isBullish && !isDiscount)) {
      score += 30;
    } else {
      score += 15;
    }
  } else {
    score += 15;
  }

  return Math.min(100, score);
};

export const Dashboard: React.FC<DashboardProps> = ({ instruments, onTriggerScenario }) => {
  const indices = instruments.filter(inst => ['NIFTY', 'BANKNIFTY', 'SENSEX'].includes(inst.instrument));
  const stocks = instruments.filter(inst => !['NIFTY', 'BANKNIFTY', 'SENSEX'].includes(inst.instrument));

  const getVetoLabel = (veto: string) => {
    switch (veto) {
      case 'V0': return 'Data Stale (> 6 min old)';
      case 'V1': return 'Expiry Day Violation';
      case 'V2': return 'Late Clock (> 13:15 IST)';
      case 'V3': return 'Deep Stretch Violation (z >= 2.5)';
      case 'V4': return 'Avalanche Trend Live';
      case 'V5': return 'Both-Legs OI Spiking';
      case 'V6': return 'Unconfirmed Solo Breakout';
      case 'V7': return 'Unqualified Asset or Option Expression';
      default: return 'Gating Veto Tripped';
    }
  };

  const getVetoEvidence = (veto: string) => {
    switch (veto) {
      case 'V0': return 'System integrity check failed. Newest bar is older than 6 minutes.';
      case 'V1': return 'Expiry-day fades produce -20.7% excess (n=407). Hard restriction.';
      case 'V2': return 'Trigger clock in late session produces -10.6% decay profile after 13:30.';
      case 'V3': return 'Deep stretches over 2.5σ are self-reinforcing trends. Reverse entry is a suicide run.';
      case 'V4': return 'Mirror premium high consecutive confirm active. Avalanche in progress.';
      case 'V5': return 'Both CE and PE market makers are liquidating. Double wall trap.';
      case 'V6': return 'No corroborating indexes stretch. Index break was 0-for-16 in historical audit.';
      case 'V7': return 'BANKNIFTY or stock option premium trades are banned. Cash/Futures only.';
      default: return 'No negotiation. Trade execution aborted.';
    }
  };

  return (
    <div className="space-y-6">
      {/* Visual Header / Active Setup Count */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-xl font-semibold font-display tracking-tight flex items-center gap-2">
            <ShieldAlert className="text-emerald-500 w-5 h-5" />
            Trade Shield Console
          </h1>
          <p className="text-xs text-gray-500 font-mono mt-1">
            VERDICT CORE v1.1 • DISCIPLINED REFUSALS ACTIVE
          </p>
        </div>

        {/* Diagnostic scenarios */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onTriggerScenario('NIFTY', 'ARMED')}
            className="px-2.5 py-1 text-xs font-mono rounded bg-amber-900/40 text-amber-300 border border-amber-800 hover:bg-amber-800/60 transition flex items-center gap-1"
          >
            <Play className="w-3 h-3" /> Arm Nifty
          </button>
          <button
            onClick={() => onTriggerScenario('NIFTY', 'TRIGGER')}
            className="px-2.5 py-1 text-xs font-mono rounded bg-emerald-950 text-emerald-400 border border-emerald-800 hover:bg-emerald-900 transition flex items-center gap-1"
          >
            <Play className="w-3 h-3" /> Trigger Nifty
          </button>
          <button
            onClick={() => onTriggerScenario('NIFTY', 'BLACKOUT')}
            className="px-2.5 py-1 text-xs font-mono rounded bg-red-950 text-red-400 border border-red-800 hover:bg-red-900 transition flex items-center gap-1"
          >
            <Play className="w-3 h-3" /> Veto Blackout
          </button>
          <button
            onClick={() => onTriggerScenario('NIFTY', 'RESET')}
            className="px-2.5 py-1 text-xs font-mono rounded bg-gray-800 text-gray-400 border border-gray-700 hover:bg-gray-700 transition"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Grid of Active Indices */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {indices.map(idx => {
          const isBlackout = idx.state === 'STAND_DOWN' || idx.activeVeto !== null;
          const zScore = idx.zAtTrigger || idx.zAtArm || 0.0;

          return (
            <div
              key={idx.instrument}
              id={`panel-${idx.instrument}`}
              className="relative bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5 overflow-hidden transition-all duration-300 shadow-md min-h-[400px] flex flex-col justify-between"
            >
              {/* Blackout Overlay state */}
              <AnimatePresence>
                {isBlackout && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0 bg-[#0C0D0F] z-20 p-6 flex flex-col justify-center items-center text-center space-y-4"
                  >
                    <div className="p-3 bg-red-950/40 rounded-full border border-red-800 text-red-500 animate-pulse">
                      <AlertCircle className="w-8 h-8" />
                    </div>
                    <span className="text-red-500 text-2xl font-bold font-display uppercase tracking-wider">
                      STAND DOWN
                    </span>
                    <div className="max-w-md space-y-2">
                      <h4 className="text-gray-200 font-semibold text-sm">
                        {idx.activeVeto ? getVetoLabel(idx.activeVeto) : 'V4: Avalanche Signal Detected'}
                      </h4>
                      <p className="text-gray-500 text-xs font-mono leading-relaxed">
                        {idx.activeVeto ? getVetoEvidence(idx.activeVeto) : 'Mirror premium high consecutive confirm active. Severe risk of trend elongation. Reversion fades are strictly banned.'}
                      </p>
                    </div>
                    <span className="text-[10px] text-red-800 font-mono tracking-widest uppercase mt-4">
                      No Negotiation • System Overriding
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Standard Active Panel UI */}
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-[#2A2E33] pb-3">
                  <div>
                    <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">
                      3-MIN • {idx.instrument === 'SENSEX' ? 'BSE' : 'NSE'}
                    </span>
                    <h2 className="text-lg font-bold font-display text-gray-100 flex items-center gap-1.5">
                      {idx.instrument} Options
                    </h2>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-gray-500 font-mono">Anchor Strike</span>
                    <div className="text-sm font-semibold font-mono text-[#E8E6E1]">
                      {idx.anchorStrike || 'Warming...'}
                    </div>
                  </div>
                </div>

                {/* Verdict Display */}
                <div className="py-2">
                  <span className="text-[10px] text-gray-500 font-mono tracking-widest uppercase block">
                    Shield Core Verdict
                  </span>
                  <div
                    className={`text-2xl md:text-3xl font-bold font-display tracking-tight transition-colors duration-300 ${
                      idx.verdict === 'FADE LONG' ? 'text-emerald-500' :
                      idx.verdict === 'FADE SHORT' ? 'text-rose-500' :
                      idx.verdict === 'OBSERVE' ? 'text-amber-500' : 'text-gray-500'
                    }`}
                  >
                    {idx.verdict === 'NOTHING' ? 'NOTHING QUALIFYING' : idx.verdict}
                  </div>
                  <p className="text-xs text-gray-400 font-mono mt-1">
                    {idx.verdict !== 'NOTHING' ? (
                      `z = ${zScore.toFixed(2)} at trigger • Mirror rejection verified • dte ${idx.dte} • Size Notch ${idx.sizeNotch}`
                    ) : (
                      `Scanning... Current z-score is outside the trigger bands. (${(idx.zAtArm || 0).toFixed(2)})`
                    )}
                  </p>
                </div>

                {/* Mirror Gauges Strip (Section 7.2) */}
                <div className="grid grid-cols-3 gap-2 bg-[#101214] border border-[#2A2E33] rounded p-3">
                  <div className="text-center space-y-1">
                    <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">Spot-TWAP</span>
                    <div className="font-mono text-xs text-gray-300 font-semibold">
                      z = {zScore.toFixed(2)}
                    </div>
                    <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden relative">
                      <div
                        className="absolute h-full bg-indigo-500 transition-all duration-300"
                        style={{
                          left: '50%',
                          width: `${Math.min(50, Math.abs(zScore) * 20)}%`,
                          transform: zScore < 0 ? 'translateX(-100%)' : 'none'
                        }}
                      />
                    </div>
                    <span className="text-[9px] text-gray-500 block">
                      {Math.abs(zScore) >= 2.0 ? 'Stretched' : 'Calm'}
                    </span>
                  </div>

                  <div className="text-center space-y-1">
                    <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">K CE Premium</span>
                    <div className="font-mono text-xs text-gray-300 font-semibold">
                      {idx.direction === 'down' ? 'Rejected' : 'Flattening'}
                    </div>
                    <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden relative">
                      <div
                        className={`absolute h-full rounded-full transition-all duration-300 ${idx.direction === 'down' ? 'bg-emerald-500 w-full' : 'bg-gray-600 w-1/3'}`}
                      />
                    </div>
                    <span className="text-[9px] text-gray-500 block">Premium sensor</span>
                  </div>

                  <div className="text-center space-y-1">
                    <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">K PE Premium</span>
                    <div className="font-mono text-xs text-gray-300 font-semibold">
                      {idx.direction === 'up' ? 'Rejected' : 'Flattening'}
                    </div>
                    <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden relative">
                      <div
                        className={`absolute h-full rounded-full transition-all duration-300 ${idx.direction === 'up' ? 'bg-rose-500 w-full' : 'bg-gray-600 w-1/3'}`}
                      />
                    </div>
                    <span className="text-[9px] text-gray-500 block">Premium sensor</span>
                  </div>
                </div>

                {/* Plan Row (Section 6.2 & 7.2) */}
                {idx.verdict !== 'NOTHING' && idx.verdict !== 'DATA STALE' && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 border-t border-[#2A2E33] pt-4 font-mono text-xs">
                    <div className="p-2.5 bg-gray-900/50 rounded border border-gray-800">
                      <span className="text-[10px] text-emerald-500 font-bold block uppercase mb-1">Buy Expression</span>
                      <div className="text-gray-100 font-bold">ATM {idx.direction === 'down' ? 'CE' : 'PE'} Premium</div>
                      <div className="text-[10px] text-gray-500 mt-1">LTP target ~120 • Notch {idx.sizeNotch} Size</div>
                    </div>

                    <div className="p-2.5 bg-gray-900/50 rounded border border-gray-800">
                      <span className="text-[10px] text-[#7F77DD] font-bold block uppercase mb-1">Target Magnet</span>
                      <div className="text-gray-100 font-bold">SMC unmitigated OB</div>
                      <div className="text-[10px] text-gray-500 mt-1">Scale half @ +20% / trail rest</div>
                    </div>

                    <div className="p-2.5 bg-rose-950/20 rounded border border-rose-900/40 animate-pulse">
                      <span className="text-[10px] text-rose-500 font-bold block uppercase mb-1">Wrong If</span>
                      <div className="text-gray-100 font-bold">Spot closes &gt; 2.5σ</div>
                      <div className="text-[10px] text-gray-500 mt-1">Or winning leg prints new high</div>
                    </div>
                  </div>
                )}
              </div>

              {/* SMC status metadata & Radial Confidence Gauge inside index */}
              {idx.smc && (() => {
                const strength = getSMCStrength(idx.smc, idx.spotPrice || idx.anchorStrike || 0);
                const isBullish = idx.smc.trendBias === 1;
                const strokeColor = isBullish ? 'stroke-emerald-500' : 'stroke-rose-500';
                const textColor = isBullish ? 'text-emerald-400' : 'text-rose-400';
                const bgColor = isBullish ? 'bg-emerald-950/20' : 'bg-rose-950/20';
                const borderColor = isBullish ? 'border-emerald-900/40' : 'border-rose-900/40';

                const radius = 28;
                const strokeWidth = 4;
                const normalizedRadius = radius - strokeWidth;
                const circumference = normalizedRadius * 2 * Math.PI;
                const strokeDashoffset = circumference - (strength / 100) * circumference;

                return (
                  <div className={`border-t border-[#2A2E33] pt-3.5 mt-4 px-3.5 py-3 rounded-lg ${bgColor} border ${borderColor} flex items-center justify-between gap-4 font-mono`}>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5">
                        <Zap className={`w-3.5 h-3.5 ${isBullish ? 'text-emerald-400' : 'text-rose-400'} animate-pulse`} />
                        <span className="text-xs font-semibold text-gray-200">SMC Strength Gauge</span>
                      </div>
                      <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px] text-gray-400">
                        <div>Bias: <span className={`${textColor} font-bold`}>{isBullish ? 'BULLISH' : 'BEARISH'}</span></div>
                        <div>CHoCH: <span className="text-gray-200">{idx.smc.lastOpposingChochBar !== -1 ? 'ACTIVE' : 'NONE'}</span></div>
                        <div className="col-span-2">OBs: <span className="text-gray-200">{idx.smc.orderBlocks?.filter((o: any) => !o.mitigated).length || 0} active</span></div>
                      </div>
                    </div>

                    {/* Radial Progress Gauge */}
                    <div className="relative flex items-center justify-center shrink-0 w-[56px] h-[56px]">
                      <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
                        {/* Background track circle */}
                        <circle
                          stroke="#101214"
                          fill="transparent"
                          strokeWidth={strokeWidth}
                          r={normalizedRadius}
                          cx={radius}
                          cy={radius}
                        />
                        {/* Indicator circle */}
                        <motion.circle
                          className={`transition-all duration-500 ease-out ${strokeColor}`}
                          fill="transparent"
                          strokeWidth={strokeWidth}
                          strokeDasharray={circumference + ' ' + circumference}
                          style={{ strokeDashoffset }}
                          r={normalizedRadius}
                          cx={radius}
                          cy={radius}
                          initial={{ strokeDashoffset: circumference }}
                          animate={{ strokeDashoffset }}
                        />
                      </svg>
                      {/* Inner text showing percentage */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-[11px] font-bold text-gray-100">{strength}%</span>
                        <span className="text-[7px] text-gray-500 uppercase tracking-tighter">SMC</span>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          );
        })}
      </div>

      {/* Row 2: Lens rows (Visual confirmations) */}
      <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5">
        <h3 className="text-xs font-bold font-display uppercase tracking-widest text-gray-400 mb-4 flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-500" />
          Lens confirmations &amp; hard filters
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          <div className="p-3 bg-[#101214] border border-[#2A2E33] rounded flex items-start gap-2.5">
            <div className="h-2 w-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold text-gray-200">Mirror premium symmetry</h4>
              <p className="text-[11px] text-gray-500 font-mono mt-0.5 leading-relaxed">
                CE/PE premium peaks matched at extreme bands. Rejecting self-excitation.
              </p>
            </div>
          </div>

          <div className="p-3 bg-[#101214] border border-[#2A2E33] rounded flex items-start gap-2.5">
            <div className="h-2 w-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold text-gray-200">Both-legs OI spike</h4>
              <p className="text-[11px] text-gray-500 font-mono mt-0.5 leading-relaxed">
                CE and PE Open Interest check clean. No blockages detected.
              </p>
            </div>
          </div>

          <div className="p-3 bg-[#101214] border border-[#2A2E33] rounded flex items-start gap-2.5">
            <div className="h-2 w-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold text-gray-200">Level proximity (S3)</h4>
              <p className="text-[11px] text-gray-500 font-mono mt-0.5 leading-relaxed">
                PDH/PDL or standard pivot level within 0.3σ of the trigger spot.
              </p>
            </div>
          </div>

          <div className="p-3 bg-[#101214] border border-[#2A2E33] rounded flex items-start gap-2.5">
            <div className="h-2 w-2 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold text-gray-200">SMC structure alignment</h4>
              <p className="text-[11px] text-gray-500 font-mono mt-0.5 leading-relaxed">
                Equilibrium tracking, Order Blocks and Equal Highs logged dynamically.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Stock Scanner & Avalanche Paper */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Stock Scanner Table */}
        <div className="xl:col-span-8 bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-xs font-bold font-display uppercase tracking-widest text-gray-400">
                STOCKS FADE SCANNER (Options as sensor, Cash as trade)
              </h3>
              <p className="text-[10px] text-gray-500 font-mono mt-0.5">
                Beta fades blocked automatically • standard symmetric 1σ stop-targets
              </p>
            </div>
            <span className="px-2 py-0.5 text-[9px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-800 rounded">
              WHITELIST STICKY
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E33] text-gray-500 text-[10px] uppercase tracking-wider">
                  <th className="py-2.5 font-semibold">Symbol</th>
                  <th className="py-2.5 font-semibold">Dir</th>
                  <th className="py-2.5 font-semibold">z-score</th>
                  <th className="py-2.5 font-semibold">SMC Alignment</th>
                  <th className="py-2.5 font-semibold">Mirror</th>
                  <th className="py-2.5 font-semibold">Level Check</th>
                  <th className="py-2.5 font-semibold">Verdict</th>
                  <th className="py-2.5 font-semibold">Wrong If</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A2E33] text-gray-300">
                {stocks.map(st => {
                  const z = st.zAtTrigger || st.zAtArm || 0.12;
                  const isArmed = st.state === 'ARMED' || st.state === 'TRIGGER';

                  return (
                    <tr key={st.instrument} className="hover:bg-gray-800/20 transition">
                      <td className="py-3 font-semibold text-gray-100 flex items-center gap-1.5">
                        <span className={`h-1.5 w-1.5 rounded-full ${isArmed ? 'bg-amber-500 animate-pulse' : 'bg-gray-600'}`} />
                        {st.instrument}
                      </td>
                      <td className="py-3">
                        {z >= 0 ? (
                          <span className="text-rose-400 flex items-center gap-0.5"><TrendingUp className="w-3.5 h-3.5" /> High</span>
                        ) : (
                          <span className="text-emerald-400 flex items-center gap-0.5"><TrendingDown className="w-3.5 h-3.5" /> Low</span>
                        )}
                      </td>
                      <td className="py-3 font-mono text-gray-100">{z.toFixed(2)}</td>
                      <td className="py-3">
                        {st.smc ? (() => {
                          const strength = getSMCStrength(st.smc, st.spotPrice || 0);
                          const isBullish = st.smc.trendBias === 1;
                          const strokeColor = isBullish ? 'stroke-emerald-500' : 'stroke-rose-500';
                          const radius = 13;
                          const strokeWidth = 2.5;
                          const normalizedRadius = radius - strokeWidth;
                          const circumference = normalizedRadius * 2 * Math.PI;
                          const strokeDashoffset = circumference - (strength / 100) * circumference;

                          return (
                            <div className="flex items-center gap-2">
                              <div className="relative flex items-center justify-center shrink-0 w-[26px] h-[26px]">
                                <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
                                  <circle
                                    stroke="#101214"
                                    fill="transparent"
                                    strokeWidth={strokeWidth}
                                    r={normalizedRadius}
                                    cx={radius}
                                    cy={radius}
                                  />
                                  <circle
                                    className={`transition-all duration-300 ease-out ${strokeColor}`}
                                    fill="transparent"
                                    strokeWidth={strokeWidth}
                                    strokeDasharray={circumference + ' ' + circumference}
                                    style={{ strokeDashoffset }}
                                    r={normalizedRadius}
                                    cx={radius}
                                    cy={radius}
                                  />
                                </svg>
                                <div className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-gray-100">
                                  {strength}%
                                </div>
                              </div>
                              <span className={`text-[9px] px-1 py-0.5 rounded font-bold ${isBullish ? 'bg-emerald-950/40 text-emerald-400' : 'bg-rose-950/40 text-rose-400'}`}>
                                {isBullish ? 'BULL' : 'BEAR'}
                              </span>
                            </div>
                          );
                        })() : (
                          <span className="text-gray-600 font-mono">-</span>
                        )}
                      </td>
                      <td className="py-3 text-gray-500">REJECTION</td>
                      <td className="py-3 text-emerald-500">P/PDL aligned</td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          st.verdict === 'NOTHING' ? 'text-gray-500 bg-gray-900/40' : 'text-emerald-400 bg-emerald-950/40 border border-emerald-900'
                        }`}>
                          {st.verdict === 'NOTHING' ? 'SCANNING' : st.verdict}
                        </span>
                      </td>
                      <td className="py-3 text-gray-500">&gt; 1.0σ spot band</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Avalanche Paper Card */}
        <div className="xl:col-span-4 bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5 flex flex-col justify-between border-l-4 border-l-[#7F77DD]">
          <div className="space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <span className="px-2 py-0.5 text-[9px] font-mono text-[#7F77DD] bg-[#7F77DD]/10 border border-[#7F77DD]/30 rounded">
                  PAPER MODULE
                </span>
                <h3 className="text-lg font-bold font-display text-gray-100 mt-2">
                  Avalanche Ride
                </h3>
              </div>
              <Layers className="w-5 h-5 text-[#7F77DD]" />
            </div>
            <p className="text-xs text-gray-400 font-mono leading-relaxed">
              Self-exciting trend ride option purchasing. Promotes to live only after ≥30 events and win rate ≥ 35%.
            </p>
          </div>

          <div className="bg-[#101214] rounded p-3.5 border border-[#2A2E33] font-mono space-y-2 mt-4 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-500">Forward Paper Log:</span>
              <span className="text-gray-300">12 entries recorded</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Current win rate:</span>
              <span className="text-emerald-400">41.6% (+40/-30)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Expectancy status:</span>
              <span className="text-gray-300 font-semibold">POSITIVE (Warming)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
