/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { InstrumentName } from '../types';
import { Settings as SettingsIcon, Save, Key, RefreshCw, Send, HelpCircle, ToggleLeft, ToggleRight } from 'lucide-react';

interface SettingsProps {
  settings: {
    alertsEnabled: boolean;
    telegramToken: string;
    telegramChatId: string;
    dhanToken: string;
    dhanClientId: string;
    simulationMode: boolean;
  };
  tiers: {
    [key in InstrumentName]?: {
      tier: 'whitelist' | 'probation' | 'excluded';
      winRate: number;
      totalTrades: number;
    };
  };
  onSaveSettings: (updates: any) => void;
  onTriggerAuditor: (job: string) => Promise<void>;
  onSaveStrikeOverride: (instrument: InstrumentName, strike: number | undefined) => void;
}

export const Settings: React.FC<SettingsProps> = ({
  settings,
  tiers,
  onSaveSettings,
  onTriggerAuditor,
  onSaveStrikeOverride,
}) => {
  const [dhanToken, setDhanToken] = useState(settings.dhanToken);
  const [dhanClientId, setDhanClientId] = useState(settings.dhanClientId);
  const [telegramToken, setTelegramToken] = useState(settings.telegramToken);
  const [telegramChatId, setTelegramChatId] = useState(settings.telegramChatId);
  const [alertsEnabled, setAlertsEnabled] = useState(settings.alertsEnabled);
  const [simulationMode, setSimulationMode] = useState(settings.simulationMode);

  const [niftyStrike, setNiftyStrike] = useState('');
  const [sensexStrike, setSensexStrike] = useState('');

  const [auditing, setAuditing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      dhanToken,
      dhanClientId,
      telegramToken,
      telegramChatId,
      alertsEnabled,
      simulationMode,
    });
  };

  const handleAuditor = async (job: string) => {
    setAuditing(true);
    await onTriggerAuditor(job);
    setAuditing(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-semibold font-display tracking-tight flex items-center gap-2">
          <SettingsIcon className="text-gray-400 w-5 h-5" />
          Shield System Configuration
        </h1>
        <p className="text-xs text-gray-500 font-mono mt-1">
          CONFIG.YAML INJECTORS &amp; LIVE CREDENTIALS PANEL
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Core Credentials Form */}
        <div className="lg:col-span-8 bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5">
          <h2 className="text-xs font-bold font-display uppercase tracking-widest text-gray-400 mb-4 flex items-center gap-1.5">
            <Key className="w-4 h-4 text-emerald-500" />
            Security &amp; API Credentials
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[11px] font-mono text-gray-500 uppercase">Dhan Access Token</label>
                <input
                  type="password"
                  value={dhanToken}
                  onChange={e => setDhanToken(e.target.value)}
                  placeholder="Paste access-token from DhanHQ"
                  className="w-full bg-[#101214] border border-[#2A2E33] focus:border-emerald-500 rounded px-3 py-2 text-xs font-mono text-gray-100 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-mono text-gray-500 uppercase">Dhan Client ID</label>
                <input
                  type="text"
                  value={dhanClientId}
                  onChange={e => setDhanClientId(e.target.value)}
                  placeholder="Paste Client ID"
                  className="w-full bg-[#101214] border border-[#2A2E33] focus:border-emerald-500 rounded px-3 py-2 text-xs font-mono text-gray-100 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[11px] font-mono text-gray-500 uppercase">Telegram Bot Token</label>
                <input
                  type="password"
                  value={telegramToken}
                  onChange={e => setTelegramToken(e.target.value)}
                  placeholder="Paste Bot Token (botXXXXX:YYYYY)"
                  className="w-full bg-[#101214] border border-[#2A2E33] focus:border-emerald-500 rounded px-3 py-2 text-xs font-mono text-gray-100 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-mono text-gray-500 uppercase">Telegram Chat/Channel ID</label>
                <input
                  type="text"
                  value={telegramChatId}
                  onChange={e => setTelegramChatId(e.target.value)}
                  placeholder="@MyChannel or chat_id"
                  className="w-full bg-[#101214] border border-[#2A2E33] focus:border-emerald-500 rounded px-3 py-2 text-xs font-mono text-gray-100 outline-none"
                />
              </div>
            </div>

            {/* Simulation and alerts toggle */}
            <div className="border-t border-[#2A2E33] pt-4 flex flex-wrap gap-6">
              <button
                type="button"
                onClick={() => setSimulationMode(!simulationMode)}
                className="flex items-center gap-2 text-xs font-mono text-gray-300"
              >
                {simulationMode ? (
                  <ToggleRight className="w-6 h-6 text-emerald-500 shrink-0" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-gray-600 shrink-0" />
                )}
                <div>
                  <span className="font-semibold block text-left">Simulation Mode</span>
                  <span className="text-[10px] text-gray-500">Enable deterministic scenario simulation ticks</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setAlertsEnabled(!alertsEnabled)}
                className="flex items-center gap-2 text-xs font-mono text-gray-300"
              >
                {alertsEnabled ? (
                  <ToggleRight className="w-6 h-6 text-emerald-500 shrink-0" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-gray-600 shrink-0" />
                )}
                <div>
                  <span className="font-semibold block text-left">Telegram Alerts</span>
                  <span className="text-[10px] text-gray-500">Dispatch transitions strictly on verdict changes</span>
                </div>
              </button>
            </div>

            <div className="border-t border-[#2A2E33] pt-4 flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-mono font-semibold flex items-center gap-1.5 transition"
              >
                <Save className="w-4 h-4" /> Save Security Settings
              </button>
            </div>
          </form>
        </div>

        {/* Auditor and Overrides Sidebars */}
        <div className="lg:col-span-4 space-y-6">
          {/* Manual Overrides */}
          <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5">
            <h2 className="text-xs font-bold font-display uppercase tracking-widest text-gray-400 mb-3">
              Manual Strike Overrides
            </h2>
            <div className="space-y-3 font-mono text-xs">
              <div className="space-y-1">
                <span className="text-[10px] text-gray-500 uppercase">NIFTY K Override (Default near ATM)</span>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={niftyStrike}
                    onChange={e => setNiftyStrike(e.target.value)}
                    placeholder="e.g. 24200"
                    className="w-full bg-[#101214] border border-[#2A2E33] rounded px-2.5 py-1 text-xs text-gray-100 outline-none"
                  />
                  <button
                    onClick={() => {
                      onSaveStrikeOverride('NIFTY', niftyStrike ? Number(niftyStrike) : undefined);
                      alert('NIFTY override processed.');
                    }}
                    className="px-2.5 py-1 bg-gray-800 border border-gray-700 hover:bg-gray-700 text-gray-300 rounded"
                  >
                    Set
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-gray-500 uppercase">SENSEX K Override</span>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={sensexStrike}
                    onChange={e => setSensexStrike(e.target.value)}
                    placeholder="e.g. 79500"
                    className="w-full bg-[#101214] border border-[#2A2E33] rounded px-2.5 py-1 text-xs text-gray-100 outline-none"
                  />
                  <button
                    onClick={() => {
                      onSaveStrikeOverride('SENSEX', sensexStrike ? Number(sensexStrike) : undefined);
                      alert('SENSEX override processed.');
                    }}
                    className="px-2.5 py-1 bg-gray-800 border border-gray-700 hover:bg-gray-700 text-gray-300 rounded"
                  >
                    Set
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Trigger Auditor Jobs */}
          <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5">
            <h2 className="text-xs font-bold font-display uppercase tracking-widest text-gray-400 mb-3 flex items-center gap-1.5">
              <RefreshCw className={`w-3.5 h-3.5 ${auditing ? 'animate-spin text-emerald-500' : ''}`} />
              Auditor manual triggers
            </h2>
            <div className="space-y-2.5">
              <button
                onClick={() => handleAuditor('nightly')}
                disabled={auditing}
                className="w-full py-1.5 text-xs font-mono rounded bg-gray-800 hover:bg-gray-700 text-gray-200 transition border border-gray-700 flex justify-center items-center gap-1.5"
              >
                <Send className="w-3 h-3 text-emerald-400" /> Run Nightly Outcome Labeling
              </button>

              <button
                onClick={() => handleAuditor('weekly')}
                disabled={auditing}
                className="w-full py-1.5 text-xs font-mono rounded bg-gray-800 hover:bg-gray-700 text-gray-200 transition border border-gray-700 flex justify-center items-center gap-1.5"
              >
                <Send className="w-3 h-3 text-[#7F77DD]" /> Run Weekly Whitelist Requalify
              </button>

              <button
                onClick={() => handleAuditor('monthly')}
                disabled={auditing}
                className="w-full py-1.5 text-xs font-mono rounded bg-gray-800 hover:bg-gray-700 text-gray-200 transition border border-gray-700 flex justify-center items-center gap-1.5"
              >
                <Send className="w-3 h-3 text-amber-400" /> Run Monthly Placebo Benchmarking
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Whitelist Stocks Display Table */}
      <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5">
        <h2 className="text-xs font-bold font-display uppercase tracking-widest text-gray-400 mb-4">
          STOCK WHITELIST &amp; PROBATION REQUALIFICATION STATUS
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-6 gap-4 font-mono text-xs">
          {Object.keys(tiers).map(key => {
            const sym = key as InstrumentName;
            const item = tiers[sym]!;
            const tierColor = item.tier === 'whitelist' ? 'text-emerald-400' : item.tier === 'probation' ? 'text-amber-400' : 'text-rose-400';

            return (
              <div key={sym} className="bg-[#101214] border border-[#2A2E33] p-3 rounded space-y-1">
                <span className="text-gray-100 font-semibold block">{sym}</span>
                <span className={`font-bold block uppercase text-[10px] ${tierColor}`}>
                  {item.tier}
                </span>
                <div className="text-[10px] text-gray-500 mt-2">
                  <div>Win Rate: {(item.winRate * 100).toFixed(0)}%</div>
                  <div>Sample Trades: {item.totalTrades}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
