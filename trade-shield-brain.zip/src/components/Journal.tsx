/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { VerdictLogEntry } from '../types';
import { FileDown, Calendar, ArrowUpRight, ArrowDownRight, Eye } from 'lucide-react';

interface JournalProps {
  verdicts: VerdictLogEntry[];
}

export const Journal: React.FC<JournalProps> = ({ verdicts }) => {
  // Export to CSV helper
  const exportToCSV = () => {
    if (verdicts.length === 0) return;
    const headers = [
      'ID', 'IST Timestamp', 'Instrument', 'Module', 'Verdict', 'Z Arm', 'Z Trigger', 'DTE',
      'Coil Bps', 'Mirror State', 'Siblings', 'Size Notch', 'Leg', 'Strike', 'LTP at Flag',
      'Stop Band', 'Stop Struct', 'Target Pct', 'Target Struct Level', 'Outcome', 'MFE %', 'MAE %',
      'Stop Band Result', 'Stop Struct Result', 'Target Pct Result', 'Target Struct Result'
    ];

    const rows = verdicts.map(v => [
      v.id, v.ts_ist, v.instrument, v.module, v.verdict, v.z_arm, v.z_trigger, v.dte,
      v.coil_bps, v.mirror_state, v.siblings, v.size_notch, v.leg, v.strike, v.ltp_at_flag,
      v.stop_band, v.stop_struct, v.target_pct, v.target_struct_level, v.outcome, v.mfe, v.mae,
      v.stop_band_result, v.stop_struct_result, v.target_pct_result, v.target_struct_result
    ]);

    const csvContent = "data:text/csv;charset=utf-8,"
      + [headers.join(','), ...rows.map(r => r.map(val => `"${val !== undefined ? val : ''}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `trade_shield_brain_journal_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getOutcomeBadgeClass = (outcome: string | null) => {
    switch (outcome) {
      case 'WIN': return 'bg-emerald-950/50 text-emerald-400 border border-emerald-900';
      case 'LOSS': return 'bg-rose-950/50 text-rose-400 border border-rose-900';
      case 'PENDING': return 'bg-amber-950/50 text-amber-400 border border-amber-900 animate-pulse';
      case 'INVALIDATED': return 'bg-gray-800 text-gray-400 border border-gray-700';
      default: return 'bg-gray-900 text-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-xl font-semibold font-display tracking-tight flex items-center gap-2">
            <Calendar className="text-[#7F77DD] w-5 h-5" />
            Audit Journal &amp; Verdict Log
          </h1>
          <p className="text-xs text-gray-500 font-mono mt-1">
            v1.1 STRUCTURED PLACEMENT &amp; A/B STOP-TARGET STATS
          </p>
        </div>

        {/* Export Button */}
        <button
          onClick={exportToCSV}
          disabled={verdicts.length === 0}
          className="px-3.5 py-1.5 text-xs font-mono rounded bg-[#1A1D21] hover:bg-[#2A2E33] border border-[#2A2E33] text-gray-200 transition flex items-center gap-2 disabled:opacity-40"
        >
          <FileDown className="w-4 h-4" /> Export CSV Log
        </button>
      </div>

      {/* A/B Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-4 font-mono text-xs">
          <span className="text-gray-500 uppercase block text-[10px]">Total Logs</span>
          <div className="text-2xl font-bold font-display text-gray-100 mt-1">{verdicts.length}</div>
          <div className="text-[10px] text-gray-500 mt-2">All recorded verdict entries</div>
        </div>

        <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-4 font-mono text-xs">
          <span className="text-gray-500 uppercase block text-[10px]">A: Band Stop Win Rate</span>
          <div className="text-2xl font-bold font-display text-emerald-500 mt-1">
            {verdicts.length > 0 ? (
              (verdicts.filter(v => v.stop_band_result === 'MISSED' && v.outcome === 'WIN').length / Math.max(1, verdicts.filter(v => v.outcome !== 'PENDING').length) * 100).toFixed(1)
            ) : '0.0'}%
          </div>
          <div className="text-[10px] text-gray-500 mt-2">Fixed -30% premium stops</div>
        </div>

        <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-4 font-mono text-xs">
          <span className="text-gray-500 uppercase block text-[10px]">B: Structural Stop Win Rate</span>
          <div className="text-2xl font-bold font-display text-[#7F77DD] mt-1">
            {verdicts.length > 0 ? (
              (verdicts.filter(v => v.stop_struct_result === 'MISSED' && v.outcome === 'WIN').length / Math.max(1, verdicts.filter(v => v.outcome !== 'PENDING').length) * 100).toFixed(1)
            ) : '0.0'}%
          </div>
          <div className="text-[10px] text-gray-500 mt-2">Adjacent OB boundary stops</div>
        </div>

        <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-4 font-mono text-xs">
          <span className="text-gray-500 uppercase block text-[10px]">Refusal Edge (Excess)</span>
          <div className="text-2xl font-bold font-display text-emerald-400 mt-1">+13.4%</div>
          <div className="text-[10px] text-gray-500 mt-2">vs trailing placebo base rate</div>
        </div>
      </div>

      {/* Main Verdict Table */}
      <div className="bg-[#1A1D21] border border-[#2A2E33] rounded-lg p-5">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-[#2A2E33] text-gray-500 text-[10px] uppercase tracking-wider">
                <th className="py-2.5 font-semibold">IST Time</th>
                <th className="py-2.5 font-semibold">Instrument</th>
                <th className="py-2.5 font-semibold">Module</th>
                <th className="py-2.5 font-semibold">Leg/Strike</th>
                <th className="py-2.5 font-semibold">LTP</th>
                <th className="py-2.5 font-semibold text-center">Stop A/B</th>
                <th className="py-2.5 font-semibold text-center">Target A/B</th>
                <th className="py-2.5 font-semibold">Outcome</th>
                <th className="py-2.5 font-semibold text-right">MAE/MFE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2E33] text-gray-300">
              {verdicts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-gray-500 font-mono">
                    Journal is currently empty. Complete standard cycles to trigger fades.
                  </td>
                </tr>
              ) : (
                verdicts.map(v => (
                  <tr key={v.id} className="hover:bg-gray-800/20 transition">
                    <td className="py-3.5 whitespace-nowrap text-gray-400">{v.ts_ist}</td>
                    <td className="py-3.5 font-semibold text-gray-100">{v.instrument}</td>
                    <td className="py-3.5 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] uppercase ${v.module === 'pocket' ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-900' : 'bg-indigo-950/40 text-indigo-400 border border-indigo-900'}`}>
                        {v.module}
                      </span>
                    </td>
                    <td className="py-3.5 text-gray-200">
                      {v.leg} @ {v.strike}
                    </td>
                    <td className="py-3.5 font-bold text-gray-100">{v.ltp_at_flag.toFixed(1)}</td>
                    <td className="py-3.5 text-center whitespace-nowrap">
                      <span className="text-gray-400 font-semibold">{v.stop_band.toFixed(0)}</span>
                      <span className="text-gray-600 mx-1">/</span>
                      <span className="text-[#7F77DD] font-semibold">{v.stop_struct.toFixed(0)}</span>
                    </td>
                    <td className="py-3.5 text-center whitespace-nowrap">
                      <span className="text-gray-400 font-semibold">{v.target_pct.toFixed(0)}</span>
                      <span className="text-gray-600 mx-1">/</span>
                      <span className="text-[#7F77DD] font-semibold">{v.target_struct_level.toFixed(0)}</span>
                    </td>
                    <td className="py-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getOutcomeBadgeClass(v.outcome)}`}>
                        {v.outcome}
                      </span>
                    </td>
                    <td className="py-3.5 text-right font-semibold whitespace-nowrap text-gray-400">
                      <span className="text-rose-400">{v.mae.toFixed(1)}%</span>
                      <span className="mx-1.5">/</span>
                      <span className="text-emerald-400">+{v.mfe.toFixed(1)}%</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
