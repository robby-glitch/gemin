/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InstrumentName, MachineState, VerdictType, VetoType, InstrumentState, SMCState, Bar, VerdictLogEntry } from '../../src/types';
import { calculateBands, calculateCoilBps } from './bands';
import { evaluateVetoes, GateInput } from './gate';
import { calculateSMC } from './smc';
import { db } from '../db';

export interface StateMachineInputs {
  instrument: InstrumentName;
  bars: Bar[];
  isIndex: boolean;
  dte: number;
  siblingsConfirmCount: number;
  bothLegsOiRising: boolean;
  isWhitelistedStock: boolean;
  isOptionExpression: boolean;
  smc: SMCState;
  currentISTTime: string; // "HH:MM"
  lastOptionPremiumCE: number;
  lastOptionPremiumPE: number;
  ceHigh: number;
  peHigh: number;
  optionHighsLookback: Bar[]; // Last 4 bars ending at arm
}

/**
 * Executes a single state machine cycle for a given instrument
 */
export function runLifecycle(
  currentState: InstrumentState,
  inputs: StateMachineInputs
): { newState: InstrumentState; logEntry?: VerdictLogEntry } {
  const { instrument, bars, isIndex, dte, siblingsConfirmCount, bothLegsOiRising, isWhitelistedStock, isOptionExpression, smc, currentISTTime } = inputs;
  const n = bars.length;

  const resultState: InstrumentState = { ...currentState };
  resultState.lastUpdate = new Date().toISOString();
  resultState.dte = dte;

  if (n < 20) {
    resultState.state = 'DATA STALE';
    resultState.verdict = 'DATA STALE';
    return { newState: resultState };
  }

  const bandResult = calculateBands(bars, isIndex);
  const currentZ = bandResult.z;
  const lastBar = bars[n - 1];

  // Calculate Coil
  const coilBps = calculateCoilBps(lastBar.close, bandResult.sigma);
  const isCoiled = coilBps <= 9; // COILED if <= 9 bps
  resultState.coiled = isCoiled;
  resultState.coilBps = coilBps;

  // Determine Mirror Lens state
  // Section 4.3 Mirror lens
  const direction = currentZ >= 0 ? 'up' : 'down';
  const winningHigh = direction === 'down' ? inputs.peHigh : inputs.ceHigh;

  // Touch lookback (max winning.High over 4 bars ending at arm or current)
  const lookbackBars = inputs.optionHighsLookback;
  const touchHigh = lookbackBars.length > 0 ? Math.max(...lookbackBars.map(b => b.high)) : winningHigh;

  let mirrorState: 'NEUTRAL' | 'CONFIRMING' | 'AVALANCHE' | 'REJECTION' = 'NEUTRAL';
  if (winningHigh > touchHigh) {
    mirrorState = 'CONFIRMING';
    // If we have multiple consecutive confirming option snapshots, we can flag AVALANCHE
    // In our live engine, we track consecutive confirms
  } else if (Math.abs(currentZ) < 2.0) {
    mirrorState = 'REJECTION';
  }
  resultState.mirrorState = mirrorState;
  resultState.siblingsConfirmCount = siblingsConfirmCount;

  // Evaluate Vetoes at current bar
  const gateInput: GateInput = {
    instrument,
    newestBarTime: lastBar.time,
    currentISTTime,
    dte,
    zAtTrigger: currentZ,
    mirrorState,
    bothLegsOiRising,
    siblingsConfirmCount,
    isWhitelistedStock,
    isOptionExpression,
  };

  const currentVeto = evaluateVetoes(gateInput);
  resultState.activeVeto = currentVeto;

  // State Transitions
  switch (currentState.state) {
    case 'DATA STALE':
    case 'IDLE':
      // Reset variables
      resultState.direction = null;
      resultState.armBarIndex = null;
      resultState.zAtArm = null;
      resultState.zAtTrigger = null;
      resultState.verdict = 'NOTHING';

      if (Math.abs(currentZ) >= 2.0 && bandResult.trusted) {
        resultState.state = 'ARMED';
        resultState.direction = currentZ > 0 ? 'up' : 'down';
        resultState.armBarIndex = n - 1;
        resultState.zAtArm = currentZ;
      }
      break;

    case 'ARMED':
      const armIndex = currentState.armBarIndex || 0;
      const barsSinceArm = n - 1 - armIndex;

      // ARMED window is strictly 10 bars
      if (barsSinceArm > 10) {
        resultState.state = 'EXPIRED';
        resultState.verdict = 'NOTHING';
      } else {
        // Evaluate Stand downs
        if ((mirrorState as string) === 'AVALANCHE') {
          resultState.state = 'STAND_DOWN';
          resultState.verdict = 'STAND DOWN';
        } else if (bothLegsOiRising) {
          resultState.state = 'STAND_DOWN';
          resultState.verdict = 'STAND DOWN';
        } else if (currentVeto) {
          resultState.state = 'STAND_DOWN';
          resultState.verdict = 'STAND DOWN';
        } else if ((mirrorState as string) === 'REJECTION') {
          // WE HAVE A TRIGGER!
          resultState.state = 'TRIGGER';
          resultState.zAtTrigger = currentZ;

          // Sizing Ladder Notch Calculation
          let notch = 2; // Default Notch 2
          const opposingChochWithin10 = smc.lastOpposingChochBar !== -1 && (n - 1 - smc.lastOpposingChochBar) <= 10;

          const isProbation = db.getStockTiers()[instrument]?.tier === 'probation';
          if (isProbation) {
            notch = 1;
          } else {
            // Check SMC Aligned for Notch 3
            // Trend agreements and within Premium/Discount zones
            const isBullishSMC = smc.trendBias === 1;
            const trendAgrees = (currentState.direction === 'down' && isBullishSMC) || (currentState.direction === 'up' && !isBullishSMC);
            const inZoneAgrees = currentState.direction === 'down' ? lastBar.close <= smc.equilibriumZone.lower : lastBar.close >= smc.equilibriumZone.upper;

            if (mirrorState === 'REJECTION' && trendAgrees && inZoneAgrees && !isCoiled) {
              notch = 3;
            } else if (isCoiled) {
              notch = 2;
            }
          }

          // Apply demotions
          if (opposingChochWithin10) {
            notch = Math.max(1, notch - 1);
          }
          if (isCoiled && notch > 1) {
            notch = Math.max(1, notch - 1);
          }

          resultState.sizeNotch = notch;

          // Determine final Verdict
          if (dte === 1) {
            resultState.verdict = 'OBSERVE'; // dte 1 is "OBSERVE ONLY"
          } else {
            resultState.verdict = currentState.direction === 'down' ? 'FADE LONG' : 'FADE SHORT';
          }

          // Build our detailed Journal & Alert log entry
          const pocketDteThreshold = 2;
          const isPocketCandidate = (instrument === 'NIFTY' || instrument === 'SENSEX') && dte >= pocketDteThreshold;

          const log: VerdictLogEntry = {
            id: `vld_${Date.now()}_${instrument}`,
            ts_ist: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }),
            instrument,
            module: isPocketCandidate ? 'pocket' : 'scanner',
            state_from: 'ARMED',
            state_to: 'TRIGGER',
            verdict: resultState.verdict,
            veto: currentVeto,
            z_arm: currentState.zAtArm,
            z_trigger: currentZ,
            dte,
            coil_bps: coilBps,
            mirror_state: mirrorState,
            siblings: siblingsConfirmCount,
            choch_opposing: opposingChochWithin10,
            choch_age_bars: smc.lastOpposingChochBar !== -1 ? (n - 1 - smc.lastOpposingChochBar) : -1,
            size_notch: notch,
            leg: currentState.direction === 'down' ? 'K CE' : 'K PE',
            strike: currentState.anchorStrike || 0,
            ltp_at_flag: currentState.direction === 'down' ? inputs.lastOptionPremiumCE : inputs.lastOptionPremiumPE,
            stop_band: currentState.direction === 'down' ? inputs.lastOptionPremiumCE * 0.70 : inputs.lastOptionPremiumPE * 0.70, // -30%
            stop_struct: (smc.strongLow || lastBar.close) - (0.05 * bandResult.sigma), // Support zone
            target_pct: currentState.direction === 'down' ? inputs.lastOptionPremiumCE * 1.20 : inputs.lastOptionPremiumPE * 1.20, // +20%
            target_struct_level: smc.strongHigh || lastBar.close,
            outcome: 'PENDING',
            outcome_ts: null,
            mfe: 0,
            mae: 0,
            premium_max_pct: 0,
            stop_band_result: null,
            stop_struct_result: null,
            target_pct_result: null,
            target_struct_result: null,
            notes: `Auto-triggered at z=${currentZ.toFixed(2)}. Opposing CHoCH: ${opposingChochWithin10 ? 'YES' : 'NO'}.`,
          };

          return { newState: resultState, logEntry: log };
        }
      }
      break;

    case 'STAND_DOWN':
    case 'TRIGGER':
    case 'EXPIRED':
      // Return to IDLE if spot goes back inside 1.5 sigma
      if (Math.abs(currentZ) < 1.5) {
        resultState.state = 'IDLE';
        resultState.verdict = 'NOTHING';
      }
      break;
  }

  return { newState: resultState };
}
