/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InstrumentName, VetoType, MachineState } from '../../src/types';

export interface GateInput {
  instrument: InstrumentName;
  newestBarTime: string; // ISO string of newest complete bar
  currentISTTime: string; // "HH:MM" format
  dte: number;
  zAtTrigger: number;
  mirrorState: 'NEUTRAL' | 'CONFIRMING' | 'AVALANCHE' | 'REJECTION';
  bothLegsOiRising: boolean;
  siblingsConfirmCount: number;
  isWhitelistedStock: boolean;
  isOptionExpression: boolean;
}

/**
 * Evaluates vetoes in strict sequential order. First trip wins.
 * Returns the tripped veto or null if all clear.
 */
export function evaluateVetoes(input: GateInput, isAvalancheModule: boolean = false): VetoType | null {
  // V0: Data stale
  if (input.newestBarTime) {
    const lastBarMs = new Date(input.newestBarTime).getTime();
    const ageMinutes = (Date.now() - lastBarMs) / 1000 / 60;
    if (ageMinutes > 6.0) {
      return 'V0';
    }
  } else {
    return 'V0'; // No data yet
  }

  // V1: Expiry day (dte == 0 for the traded instrument)
  if (input.dte === 0) {
    return 'V1';
  }

  // V2: Late clock (new-entry trigger > 13:15 IST)
  const [hh, mm] = input.currentISTTime.split(':').map(Number);
  const totalMinutes = hh * 60 + mm;
  const cutoffMinutes = 13 * 60 + 15; // 13:15
  if (totalMinutes > cutoffMinutes) {
    return 'V2';
  }

  // V3: Deep stretch (|z| >= 2.5 at trigger)
  if (Math.abs(input.zAtTrigger) >= 2.5) {
    return 'V3';
  }

  // V4: Avalanche live (mirror == AVALANCHE)
  if (input.mirrorState === 'AVALANCHE') {
    return 'V4';
  }

  // V5: Both-legs OI (both_legs_rising)
  if (input.bothLegsOiRising) {
    return 'V5';
  }

  // V6: Solo break (for avalanche module only)
  if (isAvalancheModule && input.siblingsConfirmCount === 0) {
    return 'V6';
  }

  // V7: Unqualified instrument
  // Off whitelist, BANKNIFTY option expression, or stock option expression
  if (input.instrument === 'BANKNIFTY' && input.isOptionExpression) {
    return 'V7'; // BANKNIFTY option trades are V7'd
  }
  if (!input.isWhitelistedStock && ['HDFCBANK', 'RELIANCE', 'ICICIBANK', 'BAJFINANCE', 'SBIN', 'AXISBANK'].includes(input.instrument)) {
    return 'V7'; // Stock not whitelisted/approved
  }
  if (input.isOptionExpression && ['HDFCBANK', 'RELIANCE', 'ICICIBANK', 'BAJFINANCE', 'SBIN', 'AXISBANK'].includes(input.instrument)) {
    return 'V7'; // Stock options expressions are V7'd (cash/futures only)
  }

  return null;
}
