/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Bar, SMCState, OrderBlock, EqualHighLow } from '../../src/types';

/**
 * Strictly causal SMC calculation bar-by-bar
 */
export function calculateSMC(bars: Bar[], size: number = 5): SMCState {
  const n = bars.length;
  const state: SMCState = {
    trendBias: 1, // Start bullish
    lastOpposingChochBar: -1,
    orderBlocks: [],
    equalHighs: [],
    equalLows: [],
    confirmedLagBars: size,
    equilibriumZone: { mid: 0, upper: 0, lower: 0 },
  };

  if (n < size * 2 + 2) {
    return state;
  }

  // Calculate ATR(50)
  const atr = calculateATR(bars, 50);

  // Store confirmed pivots
  const pivotHighs: { index: number; price: number }[] = [];
  const pivotLows: { index: number; price: number }[] = [];

  let lastHighPivotPrice = bars[0].high;
  let lastLowPivotPrice = bars[0].low;
  let trendBias = 1; // +1 = bullish, -1 = bearish
  let lastOpposingChochBar = -1;

  const orderBlocks: OrderBlock[] = [];

  // Reconstruct state causally up to bar `n - 1`
  // A pivot at bar `i` is confirmed at bar `i + size`
  for (let t = size; t < n; t++) {
    const checkIdx = t - size;

    // Check for Pivot High at checkIdx
    let isPivotHigh = true;
    for (let j = Math.max(0, checkIdx - size); j <= Math.min(n - 1, checkIdx + size); j++) {
      if (j !== checkIdx && bars[j].high > bars[checkIdx].high) {
        isPivotHigh = false;
        break;
      }
    }
    if (isPivotHigh) {
      pivotHighs.push({ index: checkIdx, price: bars[checkIdx].high });
      lastHighPivotPrice = bars[checkIdx].high;

      // Check Equal Highs with previous pivot high
      if (pivotHighs.length >= 2) {
        const prev = pivotHighs[pivotHighs.length - 2];
        const current = pivotHighs[pivotHighs.length - 1];
        const currentAtr = atr[t] || 0;
        if (Math.abs(current.price - prev.price) <= 0.1 * currentAtr) {
          state.equalHighs.push({
            price: (current.price + prev.price) / 2,
            isHigh: true,
            barIndices: [prev.index, current.index],
          });
        }
      }
    }

    // Check for Pivot Low at checkIdx
    let isPivotLow = true;
    for (let j = Math.max(0, checkIdx - size); j <= Math.min(n - 1, checkIdx + size); j++) {
      if (j !== checkIdx && bars[j].low < bars[checkIdx].low) {
        isPivotLow = false;
        break;
      }
    }
    if (isPivotLow) {
      pivotLows.push({ index: checkIdx, price: bars[checkIdx].low });
      lastLowPivotPrice = bars[checkIdx].low;

      // Check Equal Lows
      if (pivotLows.length >= 2) {
        const prev = pivotLows[pivotLows.length - 2];
        const current = pivotLows[pivotLows.length - 1];
        const currentAtr = atr[t] || 0;
        if (Math.abs(current.price - prev.price) <= 0.1 * currentAtr) {
          state.equalLows.push({
            price: (current.price + prev.price) / 2,
            isHigh: false,
            barIndices: [prev.index, current.index],
          });
        }
      }
    }

    // Check for BOS / CHoCH at current bar `t` (completed)
    const currentClose = bars[t].close;

    if (trendBias === 1) {
      // Bullish Trend:
      // Check bearish CHoCH if we break the last low pivot
      if (currentClose < lastLowPivotPrice) {
        trendBias = -1;
        lastOpposingChochBar = t;
        // Create Supply OB at the extreme high bar between pivot and break
        const extremeBarIdx = findExtremeBar(bars, checkIdx, t, true);
        orderBlocks.push({
          id: `ob_supply_${t}`,
          isDemand: false,
          priceHigh: bars[extremeBarIdx].high,
          priceLow: bars[extremeBarIdx].low,
          mitigated: false,
          createdBarIndex: t,
          volume: bars[extremeBarIdx].volume,
        });
      } else if (currentClose > lastHighPivotPrice) {
        // Bullish BOS
        const extremeBarIdx = findExtremeBar(bars, checkIdx, t, false);
        orderBlocks.push({
          id: `ob_demand_${t}`,
          isDemand: true,
          priceHigh: bars[extremeBarIdx].high,
          priceLow: bars[extremeBarIdx].low,
          mitigated: false,
          createdBarIndex: t,
          volume: bars[extremeBarIdx].volume,
        });
      }
    } else {
      // Bearish Trend:
      // Check bullish CHoCH if we break the last high pivot
      if (currentClose > lastHighPivotPrice) {
        trendBias = 1;
        lastOpposingChochBar = t;
        const extremeBarIdx = findExtremeBar(bars, checkIdx, t, false);
        orderBlocks.push({
          id: `ob_demand_${t}`,
          isDemand: true,
          priceHigh: bars[extremeBarIdx].high,
          priceLow: bars[extremeBarIdx].low,
          mitigated: false,
          createdBarIndex: t,
          volume: bars[extremeBarIdx].volume,
        });
      } else if (currentClose < lastLowPivotPrice) {
        // Bearish BOS
        const extremeBarIdx = findExtremeBar(bars, checkIdx, t, true);
        orderBlocks.push({
          id: `ob_supply_${t}`,
          isDemand: false,
          priceHigh: bars[extremeBarIdx].high,
          priceLow: bars[extremeBarIdx].low,
          mitigated: false,
          createdBarIndex: t,
          volume: bars[extremeBarIdx].volume,
        });
      }
    }

    // Process mitigations up to bar `t`
    for (const ob of orderBlocks) {
      if (!ob.mitigated) {
        if (ob.isDemand) {
          // Mitigated if close goes below OB low
          if (currentClose < ob.priceLow) {
            ob.mitigated = true;
            ob.mitigatedBarIndex = t;
          }
        } else {
          // Mitigated if close goes above OB high
          if (currentClose > ob.priceHigh) {
            ob.mitigated = true;
            ob.mitigatedBarIndex = t;
          }
        }
      }
    }
  }

  // Trailing strong high/low
  let strongHigh = bars[0].high;
  let strongLow = bars[0].low;
  for (let i = 0; i < n; i++) {
    if (bars[i].high > strongHigh) strongHigh = bars[i].high;
    if (bars[i].low < strongLow) strongLow = bars[i].low;
  }

  const trailingRange = strongHigh - strongLow;
  const midPoint = strongLow + trailingRange / 2;

  state.trendBias = trendBias;
  state.lastOpposingChochBar = lastOpposingChochBar;
  state.orderBlocks = orderBlocks;
  state.strongHigh = strongHigh;
  state.strongLow = strongLow;
  state.equilibriumZone = {
    mid: midPoint,
    upper: midPoint + trailingRange * 0.025,
    lower: midPoint - trailingRange * 0.025,
  };

  return state;
}

/**
 * Finds the extreme high/low bar in a range
 */
function findExtremeBar(bars: Bar[], start: number, end: number, findHigh: boolean): number {
  let extremeIdx = start;
  let extremeVal = findHigh ? bars[start].high : bars[start].low;

  for (let i = start + 1; i <= end; i++) {
    if (findHigh) {
      if (bars[i].high > extremeVal) {
        extremeVal = bars[i].high;
        extremeIdx = i;
      }
    } else {
      if (bars[i].low < extremeVal) {
        extremeVal = bars[i].low;
        extremeIdx = i;
      }
    }
  }
  return extremeIdx;
}

/**
 * Helper to calculate Average True Range (ATR)
 */
function calculateATR(bars: Bar[], period: number = 50): number[] {
  const atr: number[] = [];
  if (bars.length === 0) return atr;

  let trSum = 0;
  for (let i = 0; i < bars.length; i++) {
    let tr = bars[i].high - bars[i].low;
    if (i > 0) {
      const prevClose = bars[i - 1].close;
      tr = Math.max(tr, Math.abs(bars[i].high - prevClose), Math.abs(bars[i].low - prevClose));
    }

    if (i < period) {
      trSum += tr;
      atr.push(trSum / (i + 1));
    } else {
      const prevAtr = atr[i - 1];
      const currentAtr = (prevAtr * (period - 1) + tr) / period;
      atr.push(currentAtr);
    }
  }
  return atr;
}
