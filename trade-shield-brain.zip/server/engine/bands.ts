/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Bar } from '../../src/types';

export interface BandResults {
  vwap: number;
  sigma: number;
  z: number;
  bands: {
    upper1: number;
    lower1: number;
    upper2: number;
    lower2: number;
    upper3: number;
    lower3: number;
  };
  trusted: boolean;
}

/**
 * Calculates VWAP/TWAP and sigma bands from completed bars
 * @param bars completed 3-minute bars
 * @param isIndex true if index spot (no volume), false if stock (has volume)
 */
export function calculateBands(bars: Bar[], isIndex: boolean): BandResults {
  const n = bars.length;
  if (n === 0) {
    return {
      vwap: 0,
      sigma: 0,
      z: 0,
      bands: { upper1: 0, lower1: 0, upper2: 0, lower2: 0, upper3: 0, lower3: 0 },
      trusted: false,
    };
  }

  let sumTpW = 0;
  let sumW = 0;

  // 1. Calculate VWAP
  for (let i = 0; i < n; i++) {
    const bar = bars[i];
    const tp = (bar.high + bar.low + bar.close) / 3;
    const w = isIndex ? 1 : (bar.volume || 1);
    sumTpW += tp * w;
    sumW += w;
  }

  const vwap = sumTpW / sumW;

  // 2. Calculate Sigma (Standard Deviation)
  let sumSquaredDiffW = 0;
  for (let i = 0; i < n; i++) {
    const bar = bars[i];
    const tp = (bar.high + bar.low + bar.close) / 3;
    const w = isIndex ? 1 : (bar.volume || 1);
    sumSquaredDiffW += w * Math.pow(tp - vwap, 2);
  }

  let sigma = Math.sqrt(sumSquaredDiffW / sumW);
  // Guard against division by zero
  if (sigma < 0.0001) {
    sigma = 0.0001;
  }

  // 3. Current Z-Score
  const lastBar = bars[n - 1];
  const z = (lastBar.close - vwap) / sigma;

  return {
    vwap,
    sigma,
    z,
    bands: {
      upper1: vwap + 1 * sigma,
      lower1: vwap - 1 * sigma,
      upper2: vwap + 2 * sigma,
      lower2: vwap - 2 * sigma,
      upper3: vwap + 3 * sigma,
      lower3: vwap - 3 * sigma,
    },
    trusted: n >= 20, // σ untrusted before bar 20 (~10:15 IST)
  };
}

/**
 * Calculates Coil Meter in bps.
 * bps = 10000 * sigma_t / Close_t
 * COILED if bps <= 9 (typically at 11:00 IST)
 */
export function calculateCoilBps(close: number, sigma: number): number {
  return (10000 * sigma) / close;
}
