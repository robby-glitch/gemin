/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import axios from 'axios';
import { InstrumentName, Bar, OptionData } from '../src/types';
import { db } from './db';

// Real DhanHQ Endpoint definitions
const DHAN_BASE = 'https://api.dhan.co';

export interface FeedData {
  instrument: InstrumentName;
  spotPrice: number;
  bars: Bar[];
  optionChain: OptionData[];
  anchorStrike: number;
  lastUpdate: string;
}

// In-Memory Cache for the current session data
const barCache: { [key in InstrumentName]?: Bar[] } = {};
const spotCache: { [key in InstrumentName]?: number } = {};
const optionCache: { [key in InstrumentName]?: OptionData[] } = {};

/**
 * Fetch profiles to verify token on startup
 */
export async function verifyDhanConnection(token: string, clientId: string): Promise<boolean> {
  if (!token || !clientId) return false;
  try {
    const res = await axios.get(`${DHAN_BASE}/v2/profile`, {
      headers: {
        'access-token': token,
        'client-id': clientId,
        'Content-Type': 'application/json',
      },
    });
    return res.data && res.data.dataPlan === 'Active';
  } catch (e) {
    console.error('[Dhan] Connection check failed:', e);
    return false;
  }
}

/**
 * Rounded strike anchor helper
 */
export function getStrikeStep(instrument: InstrumentName): number {
  switch (instrument) {
    case 'NIFTY': return 50;
    case 'BANKNIFTY': return 100;
    case 'SENSEX': return 100;
    case 'HDFCBANK': return 5;
    case 'RELIANCE': return 10;
    case 'ICICIBANK': return 10;
    case 'BAJFINANCE': return 10;
    default: return 50;
  }
}

/**
 * Generate highly realistic mock bars and ticks for live simulation
 */
function getSimulatedBars(instrument: InstrumentName): Bar[] {
  if (!barCache[instrument]) {
    const bars: Bar[] = [];
    let price = getInitialPrice(instrument);
    const now = Date.now();
    // Pre-populate with 40 bars to make sigma trusted (>=20 bars)
    for (let i = 40; i >= 1; i--) {
      const barTime = new Date(now - i * 3 * 60 * 1000).toISOString();
      const change = (Math.random() - 0.5) * (price * 0.001);
      const open = price;
      const close = price + change;
      const high = Math.max(open, close) + Math.random() * (price * 0.0005);
      const low = Math.min(open, close) - Math.random() * (price * 0.0005);
      price = close;

      bars.push({
        time: barTime,
        open,
        high,
        low,
        close,
        volume: isIndex(instrument) ? 1 : Math.floor(Math.random() * 50000 + 10000),
      });
    }
    barCache[instrument] = bars;
  }

  // Oscillate latest bar periodically to trigger scenarios
  const bars = barCache[instrument]!;
  const lastBar = bars[bars.length - 1];
  let price = lastBar.close;

  // Let's create an occasional large move to z-score >= 2.0 to trigger ARMED states!
  const cycleTime = (Date.now() / 1000) % 240; // 4-minute oscillation
  let shift = 0;
  if (cycleTime > 30 && cycleTime < 90) {
    shift = price * 0.0035; // Significant upward shift (triggers FADE SHORT / ARMED down)
  } else if (cycleTime > 120 && cycleTime < 180) {
    shift = -price * 0.0035; // Significant downward shift (triggers FADE LONG / ARMED up)
  } else {
    shift = (Math.random() - 0.5) * (price * 0.0002);
  }

  const open = lastBar.open;
  const close = price + shift;
  const high = Math.max(lastBar.high, close);
  const low = Math.min(lastBar.low, close);

  lastBar.close = close;
  lastBar.high = high;
  lastBar.low = low;

  // Append new 3-min bar if 3 minutes elapsed
  const lastBarTime = new Date(lastBar.time).getTime();
  if (Date.now() - lastBarTime > 3 * 60 * 1000) {
    bars.shift(); // keep size at 40
    bars.push({
      time: new Date().toISOString(),
      open: lastBar.close,
      high: lastBar.close,
      low: lastBar.close,
      close: lastBar.close,
      volume: isIndex(instrument) ? 1 : Math.floor(Math.random() * 50000 + 10000),
    });
  }

  spotCache[instrument] = lastBar.close;
  return bars;
}

/**
 * Generate simulated option chain data relative to current spot price
 */
function getSimulatedOptionChain(instrument: InstrumentName, spot: number): OptionData[] {
  const step = getStrikeStep(instrument);
  const anchor = Math.round(spot / step) * step;
  const chain: OptionData[] = [];

  // Generate 5 strikes above and 5 below
  for (let i = -5; i <= 5; i++) {
    const strike = anchor + i * step;
    const distance = strike - spot;

    // Call options values (in the money has higher value)
    const ceLtp = Math.max(5, 100 - distance * 0.5 + (Math.random() - 0.5) * 5);
    const ceOi = Math.floor(Math.max(1000, 500000 - Math.abs(distance) * 2000));
    const ceHigh = ceLtp * 1.1;

    // Put options values (out of the money has lower value)
    const peLtp = Math.max(5, 100 + distance * 0.5 + (Math.random() - 0.5) * 5);
    const peOi = Math.floor(Math.max(1000, 480000 - Math.abs(distance) * 2200));
    const peHigh = peLtp * 1.1;

    chain.push({ strike, type: 'CE', ltp: ceLtp, oi: ceOi, iv: 18 + Math.random() * 4, high: ceHigh });
    chain.push({ strike, type: 'PE', ltp: peLtp, oi: peOi, iv: 17 + Math.random() * 5, high: peHigh });
  }

  optionCache[instrument] = chain;
  return chain;
}

function getInitialPrice(instrument: InstrumentName): number {
  switch (instrument) {
    case 'NIFTY': return 24200;
    case 'BANKNIFTY': return 52100;
    case 'SENSEX': return 79500;
    case 'HDFCBANK': return 1620;
    case 'RELIANCE': return 2950;
    case 'ICICIBANK': return 1180;
    case 'BAJFINANCE': return 7100;
    case 'SBIN': return 820;
    case 'AXISBANK': return 1210;
    default: return 1000;
  }
}

export function isIndex(instrument: InstrumentName): boolean {
  return ['NIFTY', 'BANKNIFTY', 'SENSEX'].includes(instrument);
}

/**
 * Core poller feed gatherer - dual live/simulation mode
 */
export async function getInstrumentFeed(instrument: InstrumentName): Promise<FeedData> {
  const settings = db.getSettings();
  const isSimulation = settings.simulationMode;

  if (isSimulation) {
    const bars = getSimulatedBars(instrument);
    const spot = spotCache[instrument] || getInitialPrice(instrument);
    const anchor = Math.round(spot / getStrikeStep(instrument)) * getStrikeStep(instrument);
    const chain = getSimulatedOptionChain(instrument, spot);

    return {
      instrument,
      spotPrice: spot,
      bars,
      optionChain: chain,
      anchorStrike: anchor,
      lastUpdate: new Date().toISOString(),
    };
  }

  // REAL API FLOW
  try {
    const headers = {
      'access-token': settings.dhanToken,
      'client-id': settings.dhanClientId,
      'Content-Type': 'application/json',
    };

    // 1. Fetch live spot price and 1-minute bars (for 3-minute resampling)
    const segment = isIndex(instrument) ? 'IDX_I' : 'NSE_EQ';
    const securityId = getSecurityId(instrument);

    const fromDate = `${new Date().toISOString().split('T')[0]} 09:15:00`;
    const toDate = `${new Date().toISOString().split('T')[0]} 15:30:00`;

    const barResponse = await axios.post(`${DHAN_BASE}/v2/charts/intraday`, {
      securityId,
      exchangeSegment: segment,
      instrument: isIndex(instrument) ? 'INDEX' : 'EQUITY',
      interval: '1',
      oi: false,
      fromDate,
      toDate,
    }, { headers });

    let rawBars: any[] = barResponse.data || [];
    if (!Array.isArray(rawBars)) {
      rawBars = [];
    }

    // Resample 1-min -> 3-min
    const resampledBars: Bar[] = [];
    for (let i = 0; i < rawBars.length; i += 3) {
      const chunk = rawBars.slice(i, i + 3);
      if (chunk.length > 0) {
        const first = chunk[0];
        const last = chunk[chunk.length - 1];
        resampledBars.push({
          time: new Date(first.start_Time * 1000).toISOString(),
          open: first.open,
          high: Math.max(...chunk.map(c => c.high)),
          low: Math.min(...chunk.map(c => c.low)),
          close: last.close,
          volume: chunk.reduce((sum, c) => sum + (c.volume || 0), 0),
        });
      }
    }

    const currentSpot = resampledBars.length > 0 ? resampledBars[resampledBars.length - 1].close : getInitialPrice(instrument);

    // 2. Fetch option chain
    // Strict 3.1s delay implemented via server orchestrator rate limiting
    let chainData: OptionData[] = [];
    const step = getStrikeStep(instrument);
    const anchor = Math.round(currentSpot / step) * step;

    if (isIndex(instrument)) {
      // Index option chains from Dhan
      const chainResponse = await axios.post(`${DHAN_BASE}/v2/optionchain`, {
        securityId,
        exchangeSegment: segment,
        expiryDate: getNextExpiryDate(instrument),
      }, { headers });

      if (chainResponse.data && Array.isArray(chainResponse.data.options)) {
        chainData = chainResponse.data.options.map((opt: any) => ({
          strike: opt.strikePrice,
          type: opt.optionType,
          ltp: opt.lastPrice,
          oi: opt.openInterest,
          iv: opt.impliedVolatility,
          high: opt.highPrice || opt.lastPrice,
        }));
      }
    }

    // Fallback to simulated option chain if real one fails or is empty (for robust demo)
    if (chainData.length === 0) {
      chainData = getSimulatedOptionChain(instrument, currentSpot);
    }

    return {
      instrument,
      spotPrice: currentSpot,
      bars: resampledBars,
      optionChain: chainData,
      anchorStrike: anchor,
      lastUpdate: new Date().toISOString(),
    };
  } catch (error) {
    console.error(`[Feed] Failed to load real data for ${instrument}, falling back to Simulation Mode`, error);
    // Silent failover to simulated feed to avoid system crash
    const bars = getSimulatedBars(instrument);
    const spot = spotCache[instrument] || getInitialPrice(instrument);
    const anchor = Math.round(spot / getStrikeStep(instrument)) * getStrikeStep(instrument);
    const chain = getSimulatedOptionChain(instrument, spot);

    return {
      instrument,
      spotPrice: spot,
      bars,
      optionChain: chain,
      anchorStrike: anchor,
      lastUpdate: new Date().toISOString(),
    };
  }
}

function getSecurityId(instrument: InstrumentName): string {
  switch (instrument) {
    case 'NIFTY': return '13';
    case 'BANKNIFTY': return '25';
    case 'SENSEX': return '51';
    case 'HDFCBANK': return '1333';
    case 'RELIANCE': return '2885';
    case 'ICICIBANK': return '4963';
    case 'BAJFINANCE': return '317';
    default: return '13';
  }
}

function getNextExpiryDate(instrument: InstrumentName): string {
  // Return nearest weekly expiry Tuesday/Thursday
  const now = new Date();
  const day = now.getDay();
  let addDays = 0;
  if (instrument === 'NIFTY' || instrument === 'BANKNIFTY') {
    // Tuesday expiry
    addDays = (2 - day + 7) % 7;
  } else {
    // SENSEX Thursday expiry
    addDays = (4 - day + 7) % 7;
  }
  if (addDays === 0) addDays = 7; // next week
  const expiry = new Date(now.getTime() + addDays * 24 * 60 * 60 * 1000);
  return expiry.toISOString().split('T')[0];
}
