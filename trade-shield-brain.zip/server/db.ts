/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import { VerdictLogEntry, InstrumentName } from '../src/types';

interface DBStructure {
  verdicts: VerdictLogEntry[];
  manualStrikes: { [key in InstrumentName]?: number };
  stockTiers: {
    [key in InstrumentName]?: {
      tier: 'whitelist' | 'probation' | 'excluded';
      winRate: number;
      totalTrades: number;
    };
  };
  settings: {
    alertsEnabled: boolean;
    telegramToken: string;
    telegramChatId: string;
    dhanToken: string;
    dhanClientId: string;
    simulationMode: boolean;
    suspendedModules: string[];
  };
}

const DATA_DIR = path.join(process.cwd(), '.data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const defaultTiers: DBStructure['stockTiers'] = {
  HDFCBANK: { tier: 'whitelist', winRate: 0.66, totalTrades: 30 },
  RELIANCE: { tier: 'whitelist', winRate: 0.62, totalTrades: 30 },
  ICICIBANK: { tier: 'whitelist', winRate: 0.61, totalTrades: 30 },
  BAJFINANCE: { tier: 'probation', winRate: 0.54, totalTrades: 15 },
  SBIN: { tier: 'excluded', winRate: 0.45, totalTrades: 12 },
  AXISBANK: { tier: 'excluded', winRate: 0.48, totalTrades: 12 },
};

const initialDB: DBStructure = {
  verdicts: [],
  manualStrikes: {},
  stockTiers: defaultTiers,
  settings: {
    alertsEnabled: true,
    telegramToken: process.env.TG_TOKEN || '',
    telegramChatId: process.env.TG_CHAT || '',
    dhanToken: process.env.DHAN_TOKEN || '',
    dhanClientId: process.env.DHAN_CLIENT_ID || '',
    simulationMode: !process.env.DHAN_TOKEN, // Auto simulation mode if no key
    suspendedModules: [],
  },
};

class LocalDB {
  private memoryData: DBStructure = { ...initialDB };

  constructor() {
    this.init();
  }

  private init() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        // Ensure all top level fields exist
        this.memoryData = {
          verdicts: parsed.verdicts || [],
          manualStrikes: parsed.manualStrikes || {},
          stockTiers: parsed.stockTiers || defaultTiers,
          settings: { ...initialDB.settings, ...(parsed.settings || {}) },
        };
      } catch (e) {
        console.error('[DB] Failed to read db.json, using defaults', e);
        this.memoryData = { ...initialDB };
        this.save();
      }
    } else {
      this.memoryData = { ...initialDB };
      this.save();
    }
  }

  private save() {
    try {
      const tempFile = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempFile, JSON.stringify(this.memoryData, null, 2), 'utf-8');
      fs.renameSync(tempFile, DB_FILE);
    } catch (e) {
      console.error('[DB] Failed to save database atomically', e);
    }
  }

  public getVerdicts(): VerdictLogEntry[] {
    return this.memoryData.verdicts;
  }

  public addVerdict(entry: VerdictLogEntry) {
    this.memoryData.verdicts.unshift(entry);
    this.save();
  }

  public updateVerdict(id: string, updates: Partial<VerdictLogEntry>) {
    const idx = this.memoryData.verdicts.findIndex(v => v.id === id);
    if (idx !== -1) {
      this.memoryData.verdicts[idx] = { ...this.memoryData.verdicts[idx], ...updates };
      this.save();
    }
  }

  public getManualStrikes() {
    return this.memoryData.manualStrikes;
  }

  public setManualStrike(instrument: InstrumentName, strike: number | undefined) {
    if (strike === undefined) {
      delete this.memoryData.manualStrikes[instrument];
    } else {
      this.memoryData.manualStrikes[instrument] = strike;
    }
    this.save();
  }

  public getStockTiers() {
    return this.memoryData.stockTiers;
  }

  public updateStockTier(instrument: InstrumentName, updates: Partial<{ tier: 'whitelist' | 'probation' | 'excluded'; winRate: number; totalTrades: number }>) {
    const current = this.memoryData.stockTiers[instrument] || { tier: 'excluded', winRate: 0.50, totalTrades: 0 };
    this.memoryData.stockTiers[instrument] = { ...current, ...updates };
    this.save();
  }

  public getSettings() {
    return this.memoryData.settings;
  }

  public updateSettings(updates: Partial<DBStructure['settings']>) {
    this.memoryData.settings = { ...this.memoryData.settings, ...updates };
    this.save();
  }
}

export const db = new LocalDB();
