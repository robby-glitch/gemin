/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import axios from 'axios';
import { db } from './db';

export interface TelegramAlertPayload {
  type: 'FLAG' | 'VETO' | 'EXIT' | 'PAPER' | 'SYSTEM';
  instrument: string;
  message: string;
}

/**
 * Dispatches Telegram alerts strictly on state transition
 */
export async function sendTelegramAlert(payload: TelegramAlertPayload) {
  const settings = db.getSettings();
  if (!settings.alertsEnabled) {
    console.log(`[Alert-Muted] ${payload.type} for ${payload.instrument}: ${payload.message}`);
    return;
  }

  const token = settings.telegramToken;
  const chatId = settings.telegramChatId;

  const emoji = getEmojiForType(payload.type);
  const formattedText = `${emoji} ${payload.message}`;

  console.log(`[Alert-Dispatch] ${payload.type}: ${formattedText}`);

  if (!token || !chatId) {
    console.log(`[Alert] Telegram credentials not configured. Skipping external dispatch.`);
    return;
  }

  try {
    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    await axios.post(url, {
      chat_id: chatId,
      text: formattedText,
      parse_mode: 'HTML',
    });
  } catch (error: any) {
    console.error(`[Alert-Failed] Failed to send Telegram alert:`, error?.message || error);
  }
}

function getEmojiForType(type: TelegramAlertPayload['type']): string {
  switch (type) {
    case 'FLAG': return '🟢';
    case 'VETO': return '🔴';
    case 'EXIT': return '🟠';
    case 'PAPER': return '🟣';
    case 'SYSTEM': return '⚪';
  }
}
